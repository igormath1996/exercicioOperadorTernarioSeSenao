/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.exerciciooperadorternariosesenao;

/**
 *
 * @author Servidor 001
 */
public class ExercicioOperadorTernarioSeSenao {

    public static void main(String[] args) {
        
        String nome1 = "Igor";
        String nome2 = "Igor";
        String nome3 = new String("igor");
        
        String resultado = (nome1 == nome2)? "Igual":"Diferente";
        System.out.println(resultado);
    }
}
